
ORB
===

ORB is the kernel module for the whole suite of data reduction and
analysis tools for SITELLE: ORBS, ORCS, ...

It provides basic access to the data cubes as long as the fitting
engine of ORCS and numerous utilitary functions for the analysis of
interferometric and spectral data, imaging data, astrometry,
photometry.
